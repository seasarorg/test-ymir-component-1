Directory for Document
